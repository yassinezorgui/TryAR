import { bootstrapCameraKit } from "@snap/camera-kit";
(async function () {
  const cameraKit = await bootstrapCameraKit({
    apiToken:'eyJhbGciOiJIUzI1NiIsImtpZCI6IkNhbnZhc1MyU0hNQUNQcm9kIiwidHlwIjoiSldUIn0.eyJhdWQiOiJjYW52YXMtY2FudmFzYXBpIiwiaXNzIjoiY2FudmFzLXMyc3Rva2VuIiwibmJmIjoxNzMyODM3MTg5LCJzdWIiOiJhZjJkMTE0Zi04YzBkLTRmMmQtYjllYi1hOWI0NDI3YTQ2MTl-U1RBR0lOR343OThmYzNjOS01MGMzLTQxMDEtOTBlMC1lYjE3NzZjZGE2ZTIifQ.8_80F9LXI8wEBXt4N7ZLMdzy101B_4bq_qNrIyseMn0'
  });

  const liveRenderTarget = document.getElementById('canvas') as HTMLCanvasElement;
  const session = await cameraKit.createSession({liveRenderTarget});
  
  const mediaStream = await navigator.mediaDevices.getUserMedia({
    video: {
      facingMode: 'user'
    }
  })
  await session.setSource(mediaStream);
  await session.play();

  const lens = await cameraKit.lensRepository.loadLens('542eca82-d872-4ac9-b883-b1554abf19dd','ca478011-4d31-4ad0-b474-aafa1b1c5228');
  await session.applyLens(lens);
})();